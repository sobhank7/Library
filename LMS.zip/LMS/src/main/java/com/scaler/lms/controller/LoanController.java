package com.scaler.lms.controller;


import com.scaler.lms.model.Loan;
import com.scaler.lms.service.LoanService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/loans")
public class LoanController {
    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @GetMapping
    public List<Loan> getAllLoans() {
        return loanService.getAllLoans();
    }

    @PostMapping
    public Loan saveLoan(@RequestBody Loan loan) {
        return loanService.saveLoan(loan);
    }
}

